import view.MainView;

public class App {
    public static void main(String[] args) throws Exception {
        new MainView().menu();
    }
}
