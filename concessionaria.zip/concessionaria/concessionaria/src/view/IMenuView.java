package view;

public interface IMenuView {
    void menu();
}
